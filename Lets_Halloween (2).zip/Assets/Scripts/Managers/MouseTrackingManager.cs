using Palmmedia.ReportGenerator.Core.Reporting.Builders.Rendering;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEditor.SearchService;
using UnityEngine;

public class MouseTrackingManager : MonoBehaviour
{
    [SerializeField] private GameObject targetObject; // ��ġ�� ��ġ�� ������ ������ ������Ʈ
    GameObject target;

    private SkillBase ActivateObject;

    private SkillCoolDown skillCool;

    [SerializeField] LayerMask layermask;

    private static bool isClick = false;

    private void Start()
    {
        // ���̾ ���� ���̸� �����ϱ� ���� �ٴ� ���̾� ����
        layermask = 1 << LayerMask.NameToLayer("FLOOR");
    }

    private void Update()
    {
        if (target != null && isClick == false && Input.GetMouseButtonDown(0))
        {
            isClick = true;
            SpawnActivateObj();
            Destroy(target);
        }
    }

    public void SpawnTarget(SkillBase obj)
    {
        ActivateObject = obj;
        StartCoroutine(CospawnTarget());
    }

    public void SetAnim(SkillCoolDown skillCoolDown)
    {
        skillCool = skillCoolDown;
    }

    IEnumerator CospawnTarget()
    {
        isClick = false;
        // ī�޶󿡼� ���콺 ��ġ�� ���̸� ���ϴ�
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        RaycastHit hit;
        // ������ ���̾ ���߽�
        if (Physics.Raycast(ray, out hit, Mathf.Infinity, layermask))
        {
            target = Instantiate(targetObject, hit.point, targetObject.transform.rotation);
            while (!isClick)
            {
                Ray rayTarget = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hitTarget;
                if (Physics.Raycast(rayTarget, out hitTarget, Mathf.Infinity,layermask))
                {
                    // ���콺 ��ġ�� ��� ��ǥ ��ġ�� ��ȯ
                    target.transform.position = hitTarget.point;
                    yield return null;
                }
            }
        }
    }

    private void SpawnActivateObj()
    {
        StartCoroutine(coSpawnActivateObj());
        skillCool.UseSkill();
    }

    IEnumerator coSpawnActivateObj()
    {
        if (isClick)
        {
            SkillBase obj = Instantiate(ActivateObject, target.transform.position, ActivateObject.transform.rotation);
            obj.UseSkill();
        }
        yield return null;
    }


}
