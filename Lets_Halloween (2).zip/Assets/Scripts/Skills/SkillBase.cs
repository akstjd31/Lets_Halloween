using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SkillBase : MonoBehaviour, ISkil
{
    [SerializeField] private TextMeshProUGUI timetext;

    public string _name { get; set; }              // �̸�
    public float _cooldown { get; set; }           // ��Ÿ��
    public float _currentCooldown { get; set; }    // ���� ��Ÿ��
    public float _duration { get; set; }           // ���ӽð�
    public float _currentDuration { get; set; }    // ���� ���ӽð�
    public float range { get; set; }               // ����
    public bool IsReady { get; set; }              // �غ����

    protected bool endSkill = false;

    private SphereCollider collider;

    private float _cooldownTime = 0;
    private float _durationTime = 0;

    private float timer = 0;

    SkillCoolDown skillCooldown;

    void Start()
    {

        collider = GetComponent<SphereCollider>();

        Debug.Log(skillCooldown);
        if (collider != null )
        {
            collider.radius = range;
        }
    }

    public void UpdateTime(float cooldownTime, float durationTime)
    {
        _currentCooldown = cooldownTime;
        _currentDuration = durationTime;
        
        if (_cooldown <= _currentCooldown)
        {
            IsReady = true;
            Debug.Log("��ų �غ��");
        }

        if (_duration <= _currentDuration)
        {
            endSkill = true;
        }

        Debug.Log($"����{_currentCooldown}");
        Debug.Log($"����{_currentDuration}");
    }
    public void StartTime()
    {
        Debug.Log("��Ÿ�� �۵���");
        _cooldownTime += Time.deltaTime;
        if (!endSkill)
        {
            _durationTime += Time.deltaTime;
        }
        
        UpdateTime(_cooldownTime, _durationTime);

        if (IsReady)
        {
            _cooldownTime = 0;
            endSkill = false;
        }

        if (endSkill)
        {
            Debug.Log("����Ǿ���");
            _durationTime = 0;
            gameObject.SetActive(false);
        }
    }
    public void UseSkill()
    {
        _currentCooldown = 0;
        _currentDuration = 0;
        IsReady = false;
        Debug.Log("��ų �����");
        
        StartCoroutine(Starte());
    }

    IEnumerator Starte()
    {
        while (true)
        {
            StartTime();

            if (IsReady == true)
            {
                Destroy(gameObject);
                yield break;
            }

            yield return null;
        }
    }

    virtual public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            if (!endSkill)
            {
                // �ڽĿ��� �������̵�
            }
            Debug.Log("�������� �� ����");
        }
    }
}
